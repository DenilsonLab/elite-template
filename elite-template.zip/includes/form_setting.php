<?php
	/*Form settings*/
	$subj = "New message from your Website"; //letter subject
	$to = 'your@gmail.com'; // Enter Your E-mail
	$from = 'website_admin@email.com'; // Admin e-mail
	$fromName = 'Elite Portfolio'; // Your company name
	$charset = 'UTF-8';
?>